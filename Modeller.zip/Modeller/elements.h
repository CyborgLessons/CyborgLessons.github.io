#ifndef ____elements__
#define ____elements__

#include <iostream>

class cube {
    double from[3];
    double to[3];
    //rotation arguments
    double origin[3];
    char axis;
    double angle;
    bool rescale;
    //Rotation arguments
public:
    
};

#endif /* defined(____cube__) */
