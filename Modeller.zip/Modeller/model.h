#ifndef ____model__
#define ____model__

#include "elements.h"
#include <iostream>

class model {
    std::string parent;
    bool ambientocclusion;
    //display ****TBC****
    bool third_right;
    bool first_right;
    bool gui;
    bool head;
    bool ground;
    bool fixed;
    //display
    //texture
    cube cubes[];
    //texture
public:
    
};

#endif /* defined(____model__) */
