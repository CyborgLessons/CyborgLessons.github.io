#include "modeller.h"

using namespace std;

int main(void) {
    
    cube cubes;
    
    return 0;
}